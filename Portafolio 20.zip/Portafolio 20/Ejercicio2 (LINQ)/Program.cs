﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2__LINQ_
{
    class Program
    {
        static void Main(string[] args)
        {
            var autos = new[]
            {
              new { Marca = "Toyota", Precio = 40000, Modelo = 2020 },
              new { Marca = "Honda", Precio = 30000, Modelo = 2020 },
              new { Marca = "Toyota", Precio = 50000, Modelo = 2022 },
              new { Marca = "Honda", Precio = 35000, Modelo = 2022 },
              new { Marca = "Toyota", Precio = 45000, Modelo = 2021 },
              new { Marca = "Toyota", Precio = 37000, Modelo = 2019 }
            };

            //primer bucle foreach itera a través de cada objeto auto en el arreglo autos.
            //En cada iteración del segundo bucle foreach, se verifica la condición para cada punto a

            //Precio mas alto por modelo
            Console.WriteLine("Precio más alto por modelo:");
            foreach (var auto in autos)
            {
                decimal precioMaximo = 0;  //se declara una variable que será el precio más alto

                foreach (var otroAuto in autos)  //el foreach recorrerá el arreglo y comparará el precio de cada elemento
                {
                    if (auto.Modelo == otroAuto.Modelo && otroAuto.Precio > precioMaximo) //Si el precio del modelo de un carro es mayor que el del resto una vez comparados, se toma ese 
                    {                                                                      //valor y se asigna a precioMaximo
                        precioMaximo = otroAuto.Precio;
                    }
                }

                Console.WriteLine($"Modelo: {auto.Modelo}, Precio más alto: {precioMaximo}");
            }

            Console.WriteLine("\nPrecio más bajo por modelo:");
            foreach (var auto in autos)
            {    //se sigue una lógica muy similar al caso anterior, pero esta vez a la inversa, ya que el precio que se busca es el más bajo
                // de todos los carros
                decimal precioMinimo = decimal.MaxValue;

                foreach (var otroAuto in autos)
                {
                    if (auto.Modelo == otroAuto.Modelo && otroAuto.Precio < precioMinimo)
                    {
                        precioMinimo = otroAuto.Precio;
                    }
                }

                Console.WriteLine($"Modelo: {auto.Modelo}, Precio más bajo: {precioMinimo}");
            }

            Console.WriteLine("\nSuma total de precios por modelo:");
            foreach (var auto in autos)
            {
                // Inicializamos una variable para almacenar la suma de precios de autos del mismo modelo
                decimal sumaPrecios = 0;

                foreach (var otroAuto in autos)
                {
                    // Verificar si el modelo del auto actual es igual al modelo del otro auto
                    if (auto.Modelo == otroAuto.Modelo)
                    {
                        // Si los modelos coinciden, agregar el precio del otro auto a la suma
                        sumaPrecios += otroAuto.Precio;
                    }
                }

                //Imprimir el modelo del auto actual y la suma total de precios de autos con el mismo modelo
                Console.WriteLine($"Modelo: {auto.Modelo}, Suma de precios: {sumaPrecios}");

                Console.ReadKey();
            }





        }
    }
}
