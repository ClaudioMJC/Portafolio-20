﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1__LINQ_
{
    class Program
    {
        static void Main(string[] args)
        {
            // Arreglo de Materias
            var materias = new[]
            {
                new { Cod = 1, Nombre = "Economía", Creditos = 4 },
                new { Cod = 2, Nombre = "Historia", Creditos = 3 },
                new { Cod = 3, Nombre = "Biología", Creditos = 5 },
                new { Cod = 4, Nombre = "Programación", Creditos = 4 },
                new { Cod = 5, Nombre = "Filosofía", Creditos = 3 },
                new { Cod = 6, Nombre = "Física", Creditos = 4 }
            };

            // Arreglo de Estudiantes
            var estudiantes = new[]
            {
                new { Id = 1, Nombre = "Juan", Telefono = "123" },
                new { Id = 2, Nombre = "María", Telefono = "456" },
                new { Id = 3, Nombre = "Carlos", Telefono = "789" },
                new { Id = 4, Nombre = "Ana", Telefono = "101" }
            };

            // Arreglo de Matriculas
            var matriculas = new[]
            {
                new { CodMatricula = 1, Id_Estudiante = 1, Cod_Materia = 3 },
                new { CodMatricula = 2, Id_Estudiante = 2, Cod_Materia = 1 },
                new { CodMatricula = 3, Id_Estudiante = 3, Cod_Materia = 4 },
                new { CodMatricula = 4, Id_Estudiante = 1, Cod_Materia = 2 },
                new { CodMatricula = 5, Id_Estudiante = 4, Cod_Materia = 6 },
                new { CodMatricula = 6, Id_Estudiante = 2, Cod_Materia = 4 }
            };

            // Nombre de estudiantes matriculados
            //se seleccionan los nombres de estudiantes matriculados basados en el id de estos
            var nombresEstudiantes = from matricula in matriculas
                                     join estudiante in estudiantes on matricula.Id_Estudiante equals estudiante.Id
                                     select estudiante.Nombre;

            // imprime los nombres de estudiantes matriculados.
            Console.WriteLine("Nombres de estudiantes matriculados:");
            foreach (var nombre in nombresEstudiantes)
            {
                Console.WriteLine(nombre);
            }

            
            //Cantidad de veces que se ha matriculado una materia
            var cantidadMatriculasPorMateria = from matricula in matriculas
                                               group matricula by matricula.Cod_Materia into grupo // se crean grupos de matrículas que tienen el mismo código de materia
                                               select new
                                               {
                                                   Cod_Materia = grupo.Key, //codigo de la materia
                                                   CantidadMatriculas = grupo.Count() //dará la cantidad de matrículas que se han realizado para una materia en particular.
                                               };

            Console.WriteLine("\nCantidad de veces que se ha matriculado una materia:");
            foreach (var materia in cantidadMatriculasPorMateria)
            {
                Console.WriteLine($"Materia {materia.Cod_Materia}: {materia.CantidadMatriculas} veces");
            }


            //Nombre de estudiantes matriculados y nombre de la materia
            //se vinculan las tres arreglos, ya que no se puede acceder directamente de estudiantes a materias, ya que se debe acceder o pasar por 
            //matriculas, de esta forma mediante el LINQ join se accede a la información requerida
            var matriculasInfo = from matricula in matriculas
                                 join estudiante in estudiantes on matricula.Id_Estudiante equals estudiante.Id
                                 join materia in materias on matricula.Cod_Materia equals materia.Cod
                                 select new
                                 {
                                     NombreEstudiante = estudiante.Nombre,
                                     NombreMateria = materia.Nombre
                                 };
            // se imprime la información 
            Console.WriteLine("\nNombre de estudiantes matriculados y nombre de la materia:");
            foreach (var info in matriculasInfo)
            {
                Console.WriteLine($"Estudiante: {info.NombreEstudiante}, Materia: {info.NombreMateria}");
            }

            Console.ReadKey();
        }
    }
}
